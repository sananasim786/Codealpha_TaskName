// server/server.js
// Minimal e-commerce backend (demo only). Uses lowdb (JSON file) for storage.
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const { Low, JSONFile } = require('lowdb');
const { nanoid } = require('nanoid');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const JWT_SECRET = process.env.JWT_SECRET || 'ecom_dev_secret';

// Lowdb setup
const dbFile = path.join(__dirname, 'db.json');
const adapter = new JSONFile(dbFile);
const db = new Low(adapter);

async function initDB(){
  await db.read();
  db.data = db.data || { products: [], users: [], orders: [] };
  if (db.data.products.length === 0){
    // seed sample products
    db.data.products.push(
      { id: 'p1', title: 'Minimal Desk Lamp', description: 'A stylish desk lamp.', price: 1999, image: '/uploads/lamp.jpg' },
      { id: 'p2', title: 'Wireless Mouse', description: 'Ergonomic wireless mouse.', price: 1299, image: '/uploads/mouse.jpg' },
      { id: 'p3', title: 'Mechanical Keyboard', description: 'Blue switch keyboard.', price: 4599, image: '/uploads/keyboard.jpg' }
    );
    await db.write();
  }
}
initDB();

// Multer for product image upload (admin)
const UPLOADS = path.join(__dirname, 'uploads');
if (!fs.existsSync(UPLOADS)) fs.mkdirSync(UPLOADS);
const storage = multer.diskStorage({
  destination: (req,file,cb)=>cb(null, UPLOADS),
  filename: (req,file,cb)=> cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

// Public routes
app.get('/api/products', async (req,res)=>{
  await db.read();
  res.json(db.data.products);
});
app.get('/api/products/:id', async (req,res)=>{
  await db.read();
  const p = db.data.products.find(x=>x.id===req.params.id);
  if (!p) return res.status(404).json({ error:'not found' });
  res.json(p);
});

// Auth: register/login
app.post('/api/register', async (req,res)=>{
  const { email, password, name } = req.body;
  if (!email || !password) return res.status(400).json({ error:'email+password required' });
  await db.read();
  if (db.data.users.find(u=>u.email===email)) return res.status(400).json({ error:'user exists' });
  const hash = await bcrypt.hash(password, 10);
  const user = { id: nanoid(), email, name: name||'', passwordHash: hash };
  db.data.users.push(user);
  await db.write();
  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

app.post('/api/login', async (req,res)=>{
  const { email, password } = req.body;
  await db.read();
  const user = db.data.users.find(u=>u.email===email);
  if (!user) return res.status(401).json({ error:'invalid' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error:'invalid' });
  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

// Middleware to verify token
function authMiddleware(req,res,next){
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error:'unauthorized' });
  const token = auth.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch(e){ return res.status(401).json({ error:'invalid token' }); }
}

// Orders
app.post('/api/orders', authMiddleware, async (req,res)=>{
  const { items, address } = req.body; // items: [{ productId, qty }]
  if (!items || items.length===0) return res.status(400).json({ error:'empty cart' });
  await db.read();
  let total = 0;
  const lineItems = items.map(it=>{
    const p = db.data.products.find(x=>x.id===it.productId);
    const price = p ? p.price : 0;
    const amount = price * (it.qty || 1);
    total += amount;
    return { productId: it.productId, qty: it.qty||1, price };
  });
  const order = { id: nanoid(), userId: req.user.id, items: lineItems, total, address: address||{}, status: 'created', createdAt: Date.now() };
  db.data.orders.push(order);
  await db.write();
  res.json({ order });
});

app.get('/api/orders', authMiddleware, async (req,res)=>{
  await db.read();
  const userOrders = db.data.orders.filter(o=>o.userId === req.user.id);
  res.json(userOrders);
});

// Admin product upload (for adding products) - simple, no auth in demo
app.post('/api/admin/products', upload.single('image'), async (req,res)=>{
  const { title, description, price } = req.body;
  if (!title || !price || !req.file) return res.status(400).json({ error:'missing fields' });
  await db.read();
  const id = nanoid();
  const p = { id, title, description: description||'', price: parseInt(price,10), image: '/uploads/' + req.file.filename };
  db.data.products.push(p);
  await db.write();
  res.json(p);
});

// Start server
const PORT = process.env.PORT || 4000;
app.listen(PORT, ()=> console.log('Ecom server listening on ' + PORT));
