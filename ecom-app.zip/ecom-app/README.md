Mini E-commerce Store
---------------------
What is included:
- server/: Express backend using lowdb (JSON file) for products, users, orders
- client/: static HTML/CSS/JS frontend

Features:
- Product listing
- Shopping cart (localStorage)
- Product images served from server/uploads/
- User registration/login (JWT)
- Order creation (requires login)

How to run:
1. Server:
   cd server
   npm install
   node server.js
   Server runs on http://localhost:4000

2. Client:
   Open client/index.html in browser or serve it from a static server.
   The client expects server at http://localhost:4000

Notes:
- This is a minimal demo for learning. Do not use lowdb or plaintext JWT_SECRET in production.
- Add HTTPS, persistent DB (Postgres/Mongo), payment integration for production-ready app.
