const API = 'http://localhost:4000';
let PRODUCTS = [];
const cart = JSON.parse(localStorage.getItem('cart')||'[]');

async function fetchProducts(){
  const res = await fetch(API + '/api/products');
  PRODUCTS = await res.json();
  renderProducts();
  renderCart();
}

function renderProducts(){
  const el = document.getElementById('products');
  el.innerHTML = '';
  PRODUCTS.forEach(p => {
    const d = document.createElement('div'); d.className='card';
    d.innerHTML = `<img src="${API + p.image}" alt="${p.title}"/><h4>${p.title}</h4><p>${p.description}</p><strong>₹${(p.price/100).toFixed(2)}</strong>`;
    const btn = document.createElement('button'); btn.textContent='Add to cart';
    btn.onclick = ()=> { addToCart(p.id); };
    d.appendChild(btn);
    el.appendChild(d);
  });
}

function addToCart(productId){
  const item = cart.find(i=>i.productId===productId);
  if (item) item.qty += 1; else cart.push({ productId, qty:1 });
  localStorage.setItem('cart', JSON.stringify(cart));
  renderCart();
}

function renderCart(){
  const el = document.getElementById('cart-items');
  el.innerHTML = '';
  let total = 0;
  cart.forEach(i=>{
    const p = PRODUCTS.find(x=>x.id===i.productId);
    const row = document.createElement('div');
    row.innerHTML = `${p ? p.title : 'Unknown'} x ${i.qty} - ₹${((p?p.price:0)*i.qty/100).toFixed(2)}`;
    el.appendChild(row);
    total += (p?p.price:0)*i.qty;
  });
  document.getElementById('cart-total').innerText = 'Total: ₹' + (total/100).toFixed(2);
}

// Simple auth UI
function renderAuth(){
  const a = document.getElementById('auth-area');
  a.innerHTML = `<input id="email" placeholder="email"/><input id="pw" placeholder="password" type="password"/><button id="reg">Register</button><button id="login">Login</button><div id="user-info"></div>`;
  document.getElementById('reg').onclick = async ()=>{
    const email = document.getElementById('email').value; const pw = document.getElementById('pw').value;
    const r = await fetch(API + '/api/register', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password:pw})});
    const j = await r.json(); if (j.token) { localStorage.setItem('token', j.token); showUser(); } else alert(JSON.stringify(j));
  };
  document.getElementById('login').onclick = async ()=>{
    const email = document.getElementById('email').value; const pw = document.getElementById('pw').value;
    const r = await fetch(API + '/api/login', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password:pw})});
    const j = await r.json(); if (j.token) { localStorage.setItem('token', j.token); showUser(); } else alert(JSON.stringify(j));
  };
  showUser();
}

function showUser(){
  const token = localStorage.getItem('token');
  const info = document.getElementById('user-info');
  if (!token) { info.innerText = 'Not signed in'; return; }
  info.innerText = 'Signed in';
}

document.getElementById('checkout').onclick = async ()=>{
  const token = localStorage.getItem('token');
  if (!token) return alert('Please log in to checkout');
  const address = { line1: 'Demo address' };
  const items = cart.map(i=>({ productId: i.productId, qty: i.qty }));
  const r = await fetch(API + '/api/orders', {method:'POST', headers:{'Content-Type':'application/json','Authorization':'Bearer '+token}, body:JSON.stringify({ items, address })});
  const j = await r.json();
  if (j.order){ alert('Order placed: ' + j.order.id); cart.length=0; localStorage.setItem('cart', JSON.stringify(cart)); renderCart(); } else alert(JSON.stringify(j));
};

fetchProducts();
renderAuth();
