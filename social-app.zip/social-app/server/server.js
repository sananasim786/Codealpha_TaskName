// server/server.js
// Minimal social media backend (demo). Uses lowdb (JSON file) for storage.
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Low, JSONFile } = require('lowdb');
const { nanoid } = require('nanoid');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());
app.use('/static', express.static(path.join(__dirname, 'static')));

const JWT_SECRET = process.env.JWT_SECRET || 'social_dev_secret';

// Lowdb setup
const dbFile = path.join(__dirname, 'db.json');
const adapter = new JSONFile(dbFile);
const db = new Low(adapter);

async function initDB(){
  await db.read();
  db.data = db.data || { users: [], posts: [], comments: [], follows: [] };
  if (db.data.users.length === 0){
    const pw = await bcrypt.hash('password', 10);
    const alice = { id: 'u1', name: 'Alice', email: 'alice@example.com', passwordHash: pw, bio: 'Hello, I\'m Alice' };
    const bob = { id: 'u2', name: 'Bob', email: 'bob@example.com', passwordHash: pw, bio: 'Bob here' };
    db.data.users.push(alice, bob);
    db.data.posts.push({ id: 'post1', userId: 'u1', content: 'Welcome to my profile!', createdAt: Date.now(), likes: [] });
    db.data.posts.push({ id: 'post2', userId: 'u2', content: 'Nice day for coding.', createdAt: Date.now(), likes: [] });
    db.data.comments.push({ id: 'c1', postId: 'post1', userId: 'u2', content: 'Nice post!', createdAt: Date.now() });
    await db.write();
  }
}
initDB();

function authMiddleware(req,res,next){
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error:'unauthorized' });
  const token = auth.split(' ')[1];
  try { const payload = jwt.verify(token, JWT_SECRET); req.user = payload; next(); } catch(e){ return res.status(401).json({ error:'invalid token' }); }
}

// Auth
app.post('/api/register', async (req,res)=>{
  const { name, email, password, bio } = req.body;
  if (!email || !password) return res.status(400).json({ error:'email+password required' });
  await db.read();
  if (db.data.users.find(u=>u.email===email)) return res.status(400).json({ error:'user exists' });
  const hash = await bcrypt.hash(password, 10);
  const id = nanoid();
  const user = { id, name: name||'', email, passwordHash: hash, bio: bio||'' };
  db.data.users.push(user);
  await db.write();
  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, bio: user.bio } });
});

app.post('/api/login', async (req,res)=>{
  const { email, password } = req.body;
  await db.read();
  const user = db.data.users.find(u=>u.email===email);
  if (!user) return res.status(401).json({ error:'invalid' });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error:'invalid' });
  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, bio: user.bio } });
});

// Users & profiles
app.get('/api/users', async (req,res)=>{ await db.read(); res.json(db.data.users.map(u=>({ id:u.id, name:u.name, bio:u.bio }))); });
app.get('/api/users/:id', async (req,res)=>{ await db.read(); const u = db.data.users.find(x=>x.id===req.params.id); if(!u) return res.status(404).json({error:'not found'}); res.json({ id:u.id, name:u.name, bio:u.bio }); });

// Posts
app.get('/api/posts', async (req,res)=>{ await db.read(); res.json(db.data.posts.sort((a,b)=>b.createdAt-a.createdAt)); });
app.post('/api/posts', authMiddleware, async (req,res)=>{
  const { content } = req.body;
  if (!content) return res.status(400).json({ error:'content required' });
  await db.read();
  const post = { id: nanoid(), userId: req.user.id, content, createdAt: Date.now(), likes: [] };
  db.data.posts.push(post);
  await db.write();
  res.json(post);
});
app.get('/api/posts/:id', async (req,res)=>{ await db.read(); const p = db.data.posts.find(x=>x.id===req.params.id); if(!p) return res.status(404).json({ error:'not found' }); res.json(p); });

// Comments
app.post('/api/posts/:id/comments', authMiddleware, async (req,res)=>{
  const { content } = req.body;
  if (!content) return res.status(400).json({ error:'content required' });
  await db.read();
  const post = db.data.posts.find(x=>x.id===req.params.id);
  if (!post) return res.status(404).json({ error:'post not found' });
  const comment = { id: nanoid(), postId: post.id, userId: req.user.id, content, createdAt: Date.now() };
  db.data.comments.push(comment);
  await db.write();
  res.json(comment);
});
app.get('/api/posts/:id/comments', async (req,res)=>{ await db.read(); res.json(db.data.comments.filter(c=>c.postId===req.params.id).sort((a,b)=>a.createdAt-b.createdAt)); });

// Likes
app.post('/api/posts/:id/like', authMiddleware, async (req,res)=>{
  await db.read();
  const post = db.data.posts.find(x=>x.id===req.params.id);
  if (!post) return res.status(404).json({ error:'post not found' });
  if (!post.likes) post.likes = [];
  if (!post.likes.includes(req.user.id)) post.likes.push(req.user.id);
  await db.write();
  res.json({ likes: post.likes.length });
});
app.post('/api/posts/:id/unlike', authMiddleware, async (req,res)=>{
  await db.read();
  const post = db.data.posts.find(x=>x.id===req.params.id);
  if (!post) return res.status(404).json({ error:'post not found' });
  post.likes = (post.likes||[]).filter(id=>id!==req.user.id);
  await db.write();
  res.json({ likes: post.likes.length });
});

// Follow system
app.post('/api/users/:id/follow', authMiddleware, async (req,res)=>{
  await db.read();
  const target = req.params.id;
  if (target === req.user.id) return res.status(400).json({ error:'cannot follow yourself' });
  if (!db.data.follows.find(f=>f.follower===req.user.id && f.following===target)){
    db.data.follows.push({ id: nanoid(), follower: req.user.id, following: target, createdAt: Date.now() });
    await db.write();
  }
  res.json({ ok:true });
});
app.post('/api/users/:id/unfollow', authMiddleware, async (req,res)=>{
  await db.read();
  db.data.follows = db.data.follows.filter(f=>!(f.follower===req.user.id && f.following===req.params.id));
  await db.write();
  res.json({ ok:true });
});
app.get('/api/users/:id/followers', async (req,res)=>{ await db.read(); res.json(db.data.follows.filter(f=>f.following===req.params.id)); });
app.get('/api/users/:id/following', async (req,res)=>{ await db.read(); res.json(db.data.follows.filter(f=>f.follower===req.params.id)); });

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=> console.log('Social server listening on ' + PORT));
