Mini Social Media App
---------------------
What is included:
- server/: Express backend using lowdb (JSON file) for users, posts, comments, follows
- client/: static HTML/CSS/JS frontend

Features:
- User registration/login (JWT)
- Create posts
- Comment on posts
- Like posts
- Follow/unfollow users (simple endpoints)

How to run:
1. Server:
   cd server
   npm install
   node server.js
   Server runs on http://localhost:5000

2. Client:
   Open client/index.html in browser or serve it from a static server.
   The client expects server at http://localhost:5000

Notes:
- This is a minimal demo for learning. Do not use lowdb or plaintext JWT_SECRET in production.
- For production: add HTTPS, persistent DB (Postgres/Mongo), input validation, and pagination.
