const API = 'http://localhost:5000';
let USER = null;
async function fetchFeed(){
  const res = await fetch(API + '/api/posts');
  const posts = await res.json();
  renderFeed(posts);
}
function renderFeed(posts){
  const el = document.getElementById('feed');
  el.innerHTML = '';
  posts.forEach(p=>{
    const d = document.createElement('div'); d.className='post';
    d.innerHTML = `<div><strong>${p.userId}</strong> • ${new Date(p.createdAt).toLocaleString()}</div><p>${p.content}</p>
      <div><button data-id="${p.id}" class="like-btn">Like (${(p.likes||[]).length})</button> <button data-id="${p.id}" class="comment-btn">Comment</button></div>
      <div class="comments" id="comments-${p.id}"></div>`;
    el.appendChild(d);
    d.querySelector('.like-btn').onclick = ()=> toggleLike(p.id);
    d.querySelector('.comment-btn').onclick = ()=> addComment(p.id);
    loadComments(p.id);
  });
}
async function loadComments(postId){
  const res = await fetch(API + '/api/posts/' + postId + '/comments');
  const comments = await res.json();
  const cdiv = document.getElementById('comments-' + postId);
  cdiv.innerHTML = '';
  comments.forEach(c=>{ const r=document.createElement('div'); r.innerText = c.userId + ': ' + c.content; cdiv.appendChild(r); });
}
async function toggleLike(postId){
  const token = localStorage.getItem('token');
  if (!token) return alert('login to like');
  // naive: always call /like
  await fetch(API + '/api/posts/' + postId + '/like', {method:'POST', headers:{'Authorization':'Bearer '+token}});
  fetchFeed();
}
async function addComment(postId){
  const token = localStorage.getItem('token');
  if (!token) return alert('login to comment');
  const text = prompt('Comment:');
  if (!text) return;
  await fetch(API + '/api/posts/' + postId + '/comments', {method:'POST', headers:{'Content-Type':'application/json','Authorization':'Bearer '+token}, body:JSON.stringify({ content: text })});
  loadComments(postId);
}
document.getElementById('post-btn').onclick = async ()=>{
  const token = localStorage.getItem('token');
  if (!token) return alert('login to post');
  const content = document.getElementById('post-content').value;
  if (!content) return alert('enter content');
  await fetch(API + '/api/posts', {method:'POST', headers:{'Content-Type':'application/json','Authorization':'Bearer '+token}, body:JSON.stringify({ content })});
  document.getElementById('post-content').value = '';
  fetchFeed();
};

// Auth UI
function renderAuth(){
  const a = document.getElementById('auth-area');
  a.innerHTML = `<input id="email" placeholder="email"/><input id="pw" placeholder="password" type="password"/><button id="reg">Register</button><button id="login">Login</button><div id="user-info"></div>`;
  document.getElementById('reg').onclick = async ()=>{
    const email = document.getElementById('email').value; const pw = document.getElementById('pw').value;
    const r = await fetch(API + '/api/register', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password:pw})});
    const j = await r.json(); if (j.token) { localStorage.setItem('token', j.token); showUser(); } else alert(JSON.stringify(j));
  };
  document.getElementById('login').onclick = async ()=>{
    const email = document.getElementById('email').value; const pw = document.getElementById('pw').value;
    const r = await fetch(API + '/api/login', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password:pw})});
    const j = await r.json(); if (j.token) { localStorage.setItem('token', j.token); showUser(); } else alert(JSON.stringify(j));
  };
  showUser();
}
function showUser(){
  const token = localStorage.getItem('token');
  const info = document.getElementById('user-info');
  if (!token) { info.innerText = 'Not signed in'; USER = null; return; }
  info.innerText = 'Signed in'; USER = {}; // for demo, not decoding token
}

// Simple profile panel showing users and follow/unfollow
async function loadUsers(){
  const res = await fetch(API + '/api/users');
  const users = await res.json();
  const panel = document.getElementById('profile-panel');
  panel.innerHTML = '<h3>Users</h3>';
  users.forEach(u=>{
    const row = document.createElement('div');
    row.innerHTML = `<div>${u.name} <button data-id="${u.id}" class="follow-btn">Follow</button></div>`;
    panel.appendChild(row);
    row.querySelector('.follow-btn').onclick = async ()=>{
      const token = localStorage.getItem('token');
      if (!token) return alert('login to follow');
      await fetch(API + '/api/users/' + u.id + '/follow', {method:'POST', headers:{'Authorization':'Bearer '+token}});
      alert('followed ' + u.name);
    };
  });
}

fetchFeed();
renderAuth();
loadUsers();
