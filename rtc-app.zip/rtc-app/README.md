Real-Time Communication App (React + Vite client)
-------------------------------------------------
This repo contains:
  - server/: Express + Socket.io signaling server with demo JWT auth
  - client/: React + Vite client demonstrating WebRTC multi-peer, screen sharing, whiteboard

Run server:
  cd server
  npm install
  npm start

Run client:
  cd client
  npm install
  npm run dev
  Open http://localhost:5173

Notes:
  - For multiple participants, open the client in multiple browser windows/tabs.
  - Use TURN for better NAT traversal in real networks.
