// server/server.js
// Minimal signaling + auth server for local development.
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

// Simple in-memory users (for demo only)
const users = {}; // email -> { passwordHash, id }
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

app.post('/api/register', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'email+password required' });
  if (users[email]) return res.status(400).json({ error: 'user exists' });
  const hash = await bcrypt.hash(password, 10);
  const id = Date.now().toString();
  users[email] = { id, passwordHash: hash };
  const token = jwt.sign({ id, email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const u = users[email];
  if (!u) return res.status(401).json({ error: 'invalid' });
  const ok = await bcrypt.compare(password, u.passwordHash);
  if (!ok) return res.status(401).json({ error: 'invalid' });
  const token = jwt.sign({ id: u.id, email }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token });
});

// Verify token helper
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (e) { return null; }
}

// Simple room signaling via socket.io
io.use((socket, next) => {
  // expecting token in handshake auth: { token }
  const token = socket.handshake.auth && socket.handshake.auth.token;
  const user = verifyToken(token);
  if (!user) return next(new Error('unauthorized'));
  socket.user = user;
  next();
});

io.on('connection', socket => {
  console.log('socket connected', socket.id, 'user', socket.user.email);
  socket.on('join-room', ({ roomId }) => {
    socket.join(roomId);
    socket.to(roomId).emit('user-joined', { userId: socket.id, email: socket.user.email });
  });

  socket.on('signal', payload => {
    // payload: { target, data }
    const { target, data } = payload;
    if (target && data) {
      io.to(target).emit('signal', { from: socket.id, data });
    }
  });

  socket.on('whiteboard-draw', ({ roomId, data }) => {
    socket.to(roomId).emit('whiteboard-draw', { from: socket.id, data });
  });

  socket.on('file-meta', ({ roomId, meta }) => {
    // broadcast file metadata (name, size, id) - actual transfer via DataChannel or upload
    socket.to(roomId).emit('file-meta', { from: socket.id, meta });
  });

  socket.on('disconnecting', () => {
    const rooms = Array.from(socket.rooms).filter(r => r !== socket.id);
    rooms.forEach(r => socket.to(r).emit('user-left', { userId: socket.id }));
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('RTC signaling server listening on ' + PORT));
