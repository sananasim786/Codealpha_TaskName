import React, { useState } from 'react'
import Room from './components/Room'

export default function App(){
  const [token, setToken] = useState(null);
  const [roomId, setRoomId] = useState('');
  const [joined, setJoined] = useState(false);

  return (
    <div style={{ padding:20 }}>
      {!token && <Auth onToken={t=>setToken(t)} />}
      {token && !joined && (
        <div>
          <input value={roomId} onChange={e=>setRoomId(e.target.value)} placeholder="room id" />
          <button onClick={()=>setJoined(true)}>Join</button>
        </div>
      )}
      {token && joined && <Room roomId={roomId || 'default'} token={token} />}
    </div>
  )
}

function Auth({onToken}){
  const [email,setEmail]=useState('user@example.com');
  const [pw,setPw]=useState('password');
  const api = 'http://localhost:3000';
  async function register(){
    const r = await fetch(api + '/api/register', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password:pw})});
    const j = await r.json();
    if(j.token) onToken(j.token);
    else alert(JSON.stringify(j));
  }
  async function login(){
    const r = await fetch(api + '/api/login', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({email,password:pw})});
    const j = await r.json();
    if(j.token) onToken(j.token);
    else alert(JSON.stringify(j));
  }
  return (
    <div style={{ marginBottom: 12 }}>
      <h3>Auth (demo)</h3>
      <input value={email} onChange={e=>setEmail(e.target.value)} />
      <input value={pw} onChange={e=>setPw(e.target.value)} type="password" />
      <div>
        <button onClick={register}>Register</button>
        <button onClick={login}>Login</button>
      </div>
    </div>
  )
}
