import React, { useEffect, useRef } from 'react'

export default function Whiteboard({ socket, roomId }){
  const canvasRef = useRef();
  useEffect(()=>{
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let drawing = false;
    function onDown(e){ drawing=true; ctx.beginPath(); ctx.moveTo(e.offsetX, e.offsetY); }
    function onMove(e){
      if(!drawing) return;
      ctx.lineTo(e.offsetX, e.offsetY); ctx.stroke();
      if (socket && socket.connected) socket.emit('whiteboard-draw', { roomId, data: { x:e.offsetX, y:e.offsetY } });
    }
    function onUp(){ drawing=false; }
    canvas.addEventListener('pointerdown', onDown);
    canvas.addEventListener('pointermove', onMove);
    canvas.addEventListener('pointerup', onUp);
    function onRemote(e){ const d = e.detail; ctx.lineTo(d.x,d.y); ctx.stroke(); }
    window.addEventListener('remote-draw', onRemote);
    return ()=>{ canvas.removeEventListener('pointerdown', onDown); canvas.removeEventListener('pointermove', onMove); canvas.removeEventListener('pointerup', onUp); window.removeEventListener('remote-draw', onRemote); }
  }, [socket, roomId]);
  return <canvas ref={canvasRef} width={800} height={400} style={{ border:'1px solid #333', marginTop:12 }} />
}
