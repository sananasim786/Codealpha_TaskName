import React, { useEffect, useRef, useState } from 'react'
import { io } from 'socket.io-client'
import VideoTile from './VideoTile'
import Whiteboard from './Whiteboard'

const SIGNAL = 'http://localhost:3000';

export default function Room({ roomId, token }){
  const localRef = useRef();
  const [localStream, setLocalStream] = useState(null);
  const [peers, setPeers] = useState({}); // id -> MediaStream
  const socketRef = useRef();
  const pcsRef = useRef({});

  useEffect(() => {
    async function init(){
      const s = await navigator.mediaDevices.getUserMedia({ video:true, audio:true });
      setLocalStream(s);
      localRef.current.srcObject = s;

      socketRef.current = io(SIGNAL, { auth: { token } });
      socketRef.current.on('connect_error', (err)=>console.error('socket err', err));
      socketRef.current.on('connect', ()=> {
        socketRef.current.emit('join-room', { roomId });
      });

      socketRef.current.on('user-joined', async ({ userId }) => {
        // create offer
        const pc = createPc(userId, s);
        pcsRef.current[userId] = pc;
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        socketRef.current.emit('signal', { target: userId, data: { type: 'offer', sdp: pc.localDescription } });
      });

      socketRef.current.on('signal', async ({ from, data }) => {
        let pc = pcsRef.current[from];
        if (!pc){
          pc = createPc(from, s);
          pcsRef.current[from] = pc;
        }
        if (data.type === 'offer'){
          await pc.setRemoteDescription(data.sdp);
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          socketRef.current.emit('signal', { target: from, data: { type: 'answer', sdp: pc.localDescription } });
        } else if (data.type === 'answer'){
          await pc.setRemoteDescription(data.sdp);
        } else if (data.candidate){
          try{ await pc.addIceCandidate(data.candidate); } catch(e){ console.warn(e); }
        }
      });

      socketRef.current.on('whiteboard-draw', ({ from, data }) => {
        window.dispatchEvent(new CustomEvent('remote-draw', { detail: data }));
      });

      socketRef.current.on('user-left', ({ userId }) => {
        if (pcsRef.current[userId]) { pcsRef.current[userId].close(); delete pcsRef.current[userId]; }
        setPeers(prev => { const p = {...prev}; delete p[userId]; return p; });
      });
    }
    init();
    return ()=>{ if(socketRef.current) socketRef.current.disconnect(); }
  }, [roomId, token]);

  function createPc(peerId, localStream){
    const pc = new RTCPeerConnection();
    localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
    pc.onicecandidate = e => {
      if (e.candidate) socketRef.current.emit('signal', { target: peerId, data: { candidate: e.candidate } });
    };
    pc.ontrack = e => {
      setPeers(prev => ({ ...prev, [peerId]: e.streams[0] }));
    };
    pc.ondatachannel = ev => {
      const dc = ev.channel;
      dc.onmessage = (m) => console.log('dc msg', m);
    };
    return pc;
  }

  async function shareScreen(){
    const screen = await navigator.mediaDevices.getDisplayMedia({ video:true });
    const track = screen.getVideoTracks()[0];
    // replace sender tracks
    for(const id in pcsRef.current){
      const pc = pcsRef.current[id];
      const sender = pc.getSenders().find(s=>s.track && s.track.kind==='video');
      if (sender) sender.replaceTrack(track);
    }
    // stop screen -> restore when ended
    track.onended = () => {
      const cam = localStream.getVideoTracks()[0];
      for(const id in pcsRef.current){
        const pc = pcsRef.current[id];
        const sender = pc.getSenders().find(s=>s.track && s.track.kind==='video');
        if (sender) sender.replaceTrack(cam);
      }
    };
  }

  return (
    <div>
      <h3>Room: {roomId}</h3>
      <div style={{ marginBottom:8 }}>
        <button onClick={shareScreen}>Share Screen</button>
      </div>
      <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
        <div>
          <video ref={localRef} autoPlay playsInline muted style={{ width:240, height:180, background:'#000' }} />
          <div>Local</div>
        </div>
        {Object.entries(peers).map(([id, stream])=>(
          <VideoTile key={id} id={id} stream={stream} />
        ))}
      </div>
      <Whiteboard socket={socketRef.current} roomId={roomId} />
    </div>
  )
}
