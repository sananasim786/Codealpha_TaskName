import React, { useEffect, useRef } from 'react'

export default function VideoTile({ id, stream }){
  const ref = useRef();
  useEffect(()=>{ if(ref.current) ref.current.srcObject = stream; }, [stream]);
  return (
    <div>
      <video ref={ref} autoPlay playsInline style={{ width:240, height:180, background:'#000' }} />
      <div>{id}</div>
    </div>
  )
}
